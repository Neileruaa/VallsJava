import java.util.Scanner;

public class Valse {
    // Pour les E/S d'évaluation. NE PAS MODIFIER.
    final static Scanner input = new Scanner(System.in);


    public static void main(String[] args) {

        if ("help".equals(args[0])){
            /* ... */
        }
		}
        /* ... votre code ici */
}
